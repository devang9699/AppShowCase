Thanks for downloading this theme!

Theme Name: Dewi
Theme URL: https://bootstrapmade.com/dewi-free-multi-purpose-html-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com